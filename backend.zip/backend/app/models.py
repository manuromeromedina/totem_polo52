from sqlalchemy import Column, Integer, String, Text, Date, BigInteger, ForeignKey
from sqlalchemy.orm import relationship
from app.config import Base

class Empresa(Base):
    __tablename__  = "empresa"
    __table_args__ = {"schema": "public"}  # si usas otro esquema, o quítalo

    # En tu BD 'cuil' es PK en lugar de un id separado
    cuil            = Column(BigInteger, primary_key=True, index=True)
    nombre          = Column(String)
    rubro           = Column(String)
    cant_empleados  = Column(Integer)
    observaciones   = Column(Text)
    fecha_ingreso   = Column(Date)
    horario_trabajo = Column(String)

    # Relación inversa a Usuario
    usuarios        = relationship("usuario", back_populates="empresa")


class Usuario(Base):
    __tablename__  = "usuario"
    __table_args__ = {"schema": "public"}

    id_usuario      = Column(Integer, primary_key=True, index=True)
    nombre          = Column(String, unique=True, index=True)
    contrasena      = Column(String)   # aquí guardas el hash
    estado          = Column(String)
    fecha_registro  = Column(Date)
    cuil            = Column(BigInteger)

    # Ahora FK a empresa.cuil
    empresa_id      = Column(BigInteger, ForeignKey("empresa.cuil"))
    empresa         = relationship("empresa", back_populates="usuario")
