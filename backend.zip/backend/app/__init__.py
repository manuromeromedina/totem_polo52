from fastapi import FastAPI

app = FastAPI()
